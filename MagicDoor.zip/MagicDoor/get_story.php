<?php
header(header: 'Content-Type: application/json');

$stories = [
    'defense-attorney' => [
        ['text' => 'Another long day at the courthouse begins.', 'image' => 'defense-1.png'],
        ['text' => 'Reviewing case files, searching for reasonable doubt.', 'image' => 'defense-2.png'],
        ['text' => 'Meeting with a client, listening to their side of the story.', 'image' => 'defense-3.png'],
        ['text' => 'Preparing arguments that could change a life.', 'image' => 'defense-4.png'],
        ['text' => 'Justice is not just about winning, but about fairness.', 'image' => 'defense-5.png']
    ],
    'defendant' => [
        ['text' => 'Waiting in the holding cell, anxiety building.', 'image' => 'defendant-1.png'],
        ['text' => 'Meeting with my court-appointed attorney.', 'image' => 'defendant-2.png'],
        ['text' => 'The weight of the accusation feels overwhelming.', 'image' => 'defendant-3.png'],
        ['text' => 'Hoping for understanding, praying for mercy.', 'image' => 'defendant-4.png'],
        ['text' => 'One moment can change everything.', 'image' => 'defendant-5.png']
    ],
    'prosecutor' => [
        ['text' => 'Reviewing evidence with meticulous detail.', 'image' => 'prosecutor-1.png'],
        ['text' => 'Building a case that speaks for the victims.', 'image' => 'prosecutor-2.png'],
        ['text' => 'Every detail matters in the pursuit of justice.', 'image' => 'prosecutor-3.png'],
        ['text' => 'Presenting arguments with precision and passion.', 'image' => 'prosecutor-4.png'],
        ['text' => 'Justice must be served.', 'image' => 'prosecutor-5.png']
    ],
    'judge' => [
        ['text' => 'Preparing for another day of legal deliberations.', 'image' => 'judge-1.png'],
        ['text' => 'Weighing evidence with careful consideration.', 'image' => 'judge-2.png'],
        ['text' => 'The responsibility of judgment is never taken lightly.', 'image' => 'judge-3.png'],
        ['text' => 'Balancing law, evidence, and human context.', 'image' => 'judge-4.png'],
        ['text' => 'Justice is a delicate balance.', 'image' => 'judge-5.png']
    ],
    'jury' => [
        ['text' => 'Seated in the jury box, taking our civic duty seriously.', 'image' => 'jury-1.png'],
        ['text' => 'Listening intently to every piece of testimony.', 'image' => 'jury-2.png'],
        ['text' => 'The weight of decision-making is immense.', 'image' => 'jury-3.png'],
        ['text' => 'Discussing, analyzing, seeking truth.', 'image' => 'jury-4.png'],
        ['text' => 'Our verdict could change a life forever.', 'image' => 'jury-5.png']
    ]
];

if (isset($_GET['story']) && isset($stories[$_GET['story']])) {
    echo json_encode($stories[$_GET['story']]);
} else {
    echo json_encode(['error' => 'Story not found']);
}
?>