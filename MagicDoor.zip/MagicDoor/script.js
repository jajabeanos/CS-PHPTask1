document.addEventListener('DOMContentLoaded', () => {
    const doors = document.querySelectorAll('.door');
    const storyDisplay = document.getElementById('story-display');
    const storyContent = document.getElementById('story-content');
    const backBtn = document.getElementById('back-btn');

    doors.forEach(door => {
        door.addEventListener('click', () => {
            const story = door.dataset.story;
            fetch(`get_story.php?story=${story}`)
                .then(response => response.json())
                .then(data => {
                    storyDisplay.style.display = 'flex';
                    displayStory(data);
                })
                .catch(error => {
                    console.error('Error fetching story:', error);
                });
        });
    });

    backBtn.addEventListener('click', () => {
        storyDisplay.style.display = 'none';
        storyContent.innerHTML = '';
        backBtn.classList.add('hidden');
    });

    function displayStory(storyData) {
        let currentLine = 0;

        function fadeOut() {
            return new Promise(resolve => {
                storyContent.classList.remove('fade-in');
                storyContent.classList.add('fade-out');

                setTimeout(() => {
                    storyContent.innerHTML = '';
                    resolve();
                }, 600); // Match the CSS transition duration
            });
        }

        function fadeIn(imgElement, lineElement) {
            return new Promise(resolve => {
                storyContent.appendChild(imgElement);
                storyContent.appendChild(lineElement);

                // Slight delay to ensure elements are in place
                setTimeout(() => {
                    storyContent.classList.remove('fade-out');
                    storyContent.classList.add('fade-in');
                    resolve();
                },);
            });
        }

        async function showNextLine() {
            if (currentLine < storyData.length) {
                const lineElement = document.createElement('div');
                const imgElement = document.createElement('img');

                lineElement.textContent = storyData[currentLine].text;
                lineElement.style.opacity = '0';
                lineElement.style.transform = 'translateY(20px)';

                // Use relative path for images
                imgElement.src = storyData[currentLine].image
                    ? `assets/${storyData[currentLine].image.split('\\').pop()}`
                    : '';

                imgElement.alt = `Story line ${currentLine + 1}`;

                // Add error handling for image
                imgElement.onerror = function () {
                    console.error('Failed to load image:', this.src);
                    this.style.display = 'none';
                };

                // If not the first line, fade out previous content
                if (currentLine > 0) {
                    await fadeOut();
                }

                // Fade in new content
                await fadeIn(imgElement, lineElement);

                // Animate text separately for additional dynamism
                setTimeout(() => {
                    lineElement.style.transition = 'opacity 0.6s, transform 0.6s';
                    lineElement.style.opacity = '1';
                    lineElement.style.transform = 'translateY(0)';
                }, 100);

                currentLine++;

                if (currentLine === storyData.length) {
                    backBtn.classList.remove('hidden');
                    return;
                }

                setTimeout(showNextLine, 4000);
            }
        }

        showNextLine();
    }
});